To run this project.

1. Make sure to have node installed.
2. Run npm install to install dependencies.
3. Run "node server.js" to start the backend.
4. Go to localhost:3000 and try it out.

